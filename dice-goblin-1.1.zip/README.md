# dice-goblin
This is a module for FoundryVTT, created by Riptide as an extension for the Dice-So-Nice module